declare module "vue3-print-nb" {
  const anyModule: any;
  export = anyModule;
}
