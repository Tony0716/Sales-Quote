import { createWebHashHistory, createRouter } from "vue-router";
import Home from "../view/Home.vue";
import Login from "../view/Login.vue";
import Other from "../view/Other.vue";
import SysConfig from "../view/sysConfig.vue";
import ResetP from "../view/ResetP.vue";
import Changep from "../view/Changep.vue";
import SignUp from "../view/SignUp.vue";
import GreateToken from "../view/GreateToken.vue";
import AccessDenied from "../view/AccessDenied.vue";
import Upload from "../view/Upload.vue";
import ManageAccount from "../view/ManageAccount.vue";
import axios from "axios";

const routes = [
  { path: "/login", component: Login},
  { path: "/", component: Home },
  { path: "/other", component: Other},
  { path: "/sysConfig", component: SysConfig },
  { path: "/resetp", component: ResetP },
  { path: "/changep", component: Changep },
  { path: "/signup", component: SignUp },
  { path: "/token", component: GreateToken},
  { path: "/access-denied", component: AccessDenied },
  { path: "/upload", component: Upload },
  { path: "/manageAccount", component: ManageAccount },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
