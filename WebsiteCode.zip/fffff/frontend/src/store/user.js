export default {
  namespaced: true,
  // //准备页面dispacth调用方法传值 {}
  actions: {
    handleModel({ commit }, modelSelect) {
      commit("SET_MODELSELECT", modelSelect);
    },
  },
  //准备mutations-用于操作数据（state）
  mutations: {
    SET_MODELSELECT(state, modelSelect) {
      state.modelSelect = modelSelect;
    },
    SET_USERS_ELECT(state, { model, crane, specific, common }) {
        const data = { model, crane, specific, common };
        function getLableAndValue(param, hideCount) {
            const output = [];
            Object.entries(param.selections).map(([key, value]) => {
            const text = value.map((item) => {
                const target = param.options[key].find(
                (option) => option.Item_Number === item
                );
                return {
                    label: hideCount
                    ? target.QuoteDescription || "Empty Quote Description."
                    : `${target.Count} - ${
                        target.QuoteDescription || "Empty Quote Description."
                    }`,
                    price: target.Price * target.Count
                };
            });
            output.push(...text);
            });
            return output;
        }
        state.userSelections = {
            model: data.model,
            crane: data.crane,
            specific: getLableAndValue(data.specific, true),
            common: getLableAndValue(data.common),
        };
    },
    EDIT__USERS_ELECT(state, {type, operation, index, text}) {
        if (operation === 'delete') {
            state.userSelections[type].splice(index, 1);
        } else if (operation === 'add') {
            state.userSelections[type].push({label: text, price: 0});
        }
    }
  },
  state: {
    modelSelect: "",
    userSelections: {},
  },
  //准备getters-用于将state中的数据进行加工
  getters: {
    getDisplayData(state) {
      const data = state.userSelections;
      function getLableAndValue(param, hideCount) {
        const output = [];
        Object.entries(param.selections).map(([key, value]) => {
          const text = value.map((item) => {
            const target = param.options[key].find(
              (option) => option.Item_Number === item
            );
            return {
              label: hideCount
                ? target.QuoteDescription || "Empty Quote Description."
                : `${target.Count} - ${
                    target.QuoteDescription || "Empty Quote Description."
                  }`,
              price: target.Price * target.Count,
            };
          });
          output.push(...text);
        });
        return output;
      }
      return {
        model: data.model,
        crane: data.crane,
        specific: getLableAndValue(data.specific, true),
        common: getLableAndValue(data.common),
      };
    },
  },
};
