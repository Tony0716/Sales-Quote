import { createStore } from 'vuex'

import user from './user'

//导出stroe
export default  createStore({
    //此处是模块化 userAbout就是模块名
    modules:{
        userAbout:user,
    }
})