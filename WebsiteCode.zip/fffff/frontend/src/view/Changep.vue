<script setup>
import { reactive } from "vue";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();
const jump = () => {
  router.back();
};
const form = reactive({
  email: "",
  old: "",
  new: "",
  con: "",
});

const changep = () => {
  if (!checkEmail(form.email)) {
    ElMessage({
      message: "Please enter the correct email addresseckEmail",
      type: "warning",
    });
  } else if (!comparisonP(form.new, form.con)) {
    ElMessage({
      message: "Please ensure that the passwords entered twice are consistent",
      type: "warning",
    });
  } else {
    axios.post("/changep", {
      email: form.email,
      old: form.old,
      newP: form.new,
    })
    .then((response) => {
      // Handle the response from the backend here
      if (response.data.message === "Password Changed") {
        ElMessage({
          message: "Reset password successful",
          type: "success",
        })
        router.push("/login");
      }else if (response.data.message === "Incorrect"){
        ElMessage({
          message: "Incorrect email or old password",
          type: "error",
        })}
       else {
        ElMessage({
          message: "An error occurred",
          type: "error",
        });
      }
    })
    .catch((error) => {
      console.error(error);
      ElMessage({
        message: "Connection Error",
        type: "error",
      });
    });
  }
};
// 使用正则表达式来检查邮箱格式
const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
const checkEmail = (email) => {
  if (email == "") {
    return false;
  }
  return emailRegex.test(email);
};

const comparisonP = (a, b) => {
  if (a == "" || b == "") {
    return false;
  }
  if (a === b) {
    return true;
  } else {
    return false;
  }
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-main>
          <el-row :gutter="20">
            <el-col :span="6">
              <div class="title">Change Password</div>
              <el-row :gutter="20">
                <el-col :span="20">
                  <el-form :model="form" label-position="top" size="large">
                    <el-form-item label="Email">
                      <el-input
                        v-model="form.email"
                        placeholder="name@email.com"
                      />
                    </el-form-item>

                    <el-form-item label="Old Password">
                      <el-input
                        v-model="form.old"
                        placeholder="Your old password"
                        type="password"
                        show-password
                      />
                    </el-form-item>

                    <el-form-item label="New Password">
                      <el-input
                        v-model="form.new"
                        placeholder="Your new password"
                        type="password"
                        show-password
                      />
                    </el-form-item>
                    <el-form-item label="Confirm Password">
                      <el-input
                        v-model="form.con"
                        placeholder="Confirm your new password"
                        type="password"
                        show-password
                      />
                    </el-form-item>
                  </el-form>
                </el-col>
              </el-row>
            </el-col>
            <el-col :span="5" class="special_row">
              <el-button
                size="large"
                @click="changep"
                style="
                  width: 100%;
                  background: #767171;
                  color: #fff;
                  height: 70px;
                  font-weight: bold;
                  font-size: 18px;
                  margin-bottom: 50px;
                "
              >
                Submit
              </el-button>
              <div class="back" @click="jump">Cancel</div>
            </el-col>
          </el-row>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    justify-content: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;
  }
  .el-main {
    padding-top: 120px;
    padding-left: 70px;
    padding-right: 70px;
    height: calc(100vh - 99px);

    .special_row {
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      align-items: center;
      position: relative;
      .back {
        position: absolute;
        bottom: 0;
        text-align: center;
        cursor: pointer;
        font-size: large;
        transform: translateY(20px);
      }
    }
    .title {
      font-size: 48px;
      padding-bottom: 70px;
      font-weight: bold;
    }
  }
}
:deep(.el-form) {
  .el-form-item .el-form-item__label {
    font-size: large;
    color: black;
  }

  .el-input__inner {
    height: 50px !important;
  }
}
</style>
