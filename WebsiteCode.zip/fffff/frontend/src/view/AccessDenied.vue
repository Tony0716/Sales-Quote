<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <h2 style="padding-left: 50px;padding-top: 40px;">Access Denied</h2>
      <p style="padding-left: 50px;margin-top: 15px;">You do not have permission to access this page.</p>
    </el-container>
  </div>
  <div> 
    <el-button
        size="large"
        style="position: absolute; left: 50px; margin-top: 15px"
        @click="goBack">
        Go Back
      </el-button>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
const router = useRouter();
const goBack = () => {
  router.go(-2);
};
</script>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    border: 1px solid #40525c;
    img {
      width: 220px;
    }
  }
}
</style>