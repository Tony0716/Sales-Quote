<template>
  <div class="app-container" style="background: #fff">
    <el-tabs v-model="activeName">
      <el-tab-pane label="服务端设置" name="serverConfig">
        <el-card>
          <el-tabs
            v-model="serverLeftActive"
            tab-position="left"
            class="demo-tabs"
          >
            <el-tab-pane label="服务配置" name="服务配置">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="数据页大小">
                      <el-input placeholder="请输入" value="4096" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="BLOB/STRING类型标签点最大长度">
                      <el-input placeholder="请输入" value="4074" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="内存大小">
                      <el-input placeholder="请输入" value="826" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="单个客户端允许的最大连接数">
                      <el-input placeholder="请输入" value="826" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="历史数据缓存分页数">
                      <el-input placeholder="请输入" value="19456" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补历史数崛缓存分页数">
                      <el-input placeholder="请输入" value="19456" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="BLOB/STRING补历史数据绩存分女数">
                      <el-input placeholder="请输入" value="12288" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="历史数据缓存所占空间">
                      <el-input placeholder="请输入" value="826" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补历史数挥级存所占空间">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="网络据交换空间">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="方程式交换空间">
                      <el-input placeholder="请输入" value="100" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="教据库网络端口">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>
            
            <el-tab-pane label="入库配置" name="入库配置">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="中速归档区">
                      <el-input placeholder="请输入" value="40%" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补历史数据先缓存后归档时间阀伯">
                      <el-input placeholder="请输入" value="826" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="快照准入时差">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="归档策略">
                      <el-select placeholder="请选择" v-model="form_2.region">
                        <el-option label="快照数据优先归档" value="0" />
                        <el-option label="补与数据优先归档" value="1" />
                        <el-option label="自动" value="2" />
                        <el-option label="暂停归档" value="3" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补历史归档线程数">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="服务端例外过滤">
                      <el-switch
                        v-model="form_2.value1"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="按照补历史流程归档快照数据页">
                      <el-switch
                        v-model="form_2.value2"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item
                      label="强制归档补历史缓存里面未满数据页的延迟时间"
                    >
                      <el-input placeholder="请输入" value="3d" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="查询配置" name="查询配置">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="分段查询个数">
                      <el-input placeholder="请输入" value="100" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="查询结果包含快照">
                      <el-switch
                        v-model="form_3.value1"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="查询时使用加速统计">
                      <el-switch
                        v-model="form_3.value2"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="使用查询线程池查询历史数据">
                      <el-switch
                        v-model="form_3.value3"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="使用查询线程池查询历史数据的条数">
                      <el-switch
                        v-model="form_3.value4"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用曲线池">
                      <el-switch
                        v-model="form_3.value5"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线算法">
                      <el-select placeholder="请选择" v-model="form_3.region">
                        <el-option label="曲线算法1" value="0" />
                        <el-option label="曲线算法2" value="1" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线查询线程池中线程数量">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="输出曲线池日志">
                      <el-switch
                        v-model="form_3.value6"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="使用曲线池级存计算插值">
                      <el-switch
                        v-model="form_3.value7"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池的标签点容量">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池每个数据文件的标签点容量">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线缓存退出时临时缓冲区大小">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池缓存数据当前时间单位">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="查询最小时间单位显示系数">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池定时器刷新周期">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池性能计算点刷新周期">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池索引文件名称">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\goldensys\plotmem.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线池缓存文件目录">
                      <el-input
                        placeholder="请输入"
                        value="D:)Program Files\golden\plotmem\"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="曲线算法">
                      <el-select placeholder="请选择" v-model="form_3.region">
                        <el-option label="曲线算法1" value="0" />
                        <el-option label="曲线算法2" value="1" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="插值查询算法调优参数">
                      <el-input placeholder="请输入" value="" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="数据管理" name="数据管理">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动备份日的地">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动移动目的地">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="索引日录">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="常驻内存的索引大小">
                      <el-input placeholder="请输入" value="6327" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="白动管理的存档文件路径">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden(data\"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件固定时间范国">
                      <el-input placeholder="请输入" value="1d" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="创建存档文件时初始化自动增长大小">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件最小尺寸">
                      <el-input placeholder="请输入" value="50" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件初始大小">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件增长模式">
                      <el-select placeholder="请选择" v-model="form_4.region">
                        <el-option label="固定大小" value="0" />
                        <el-option label="百分比" value="1" />
                        <el-option label="存档文件自定义自增大小" value="2" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="固定模式下文件增长大小">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="百分比模式下增长百分比">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件滚动时间轴">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动备份开始时间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动备份停止时间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="跳跃链表转换到红黑树">
                      <el-switch
                        v-model="form_4.value1"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动转换索引时间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="索引格式时间轴">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="将存档文件全部读取到内存中">
                      <el-switch
                        v-model="form_4.value2"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动警理存档文件时的实际使用率">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动整理存档文件的时间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动整理存档文件时的最小使用率">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="在内存中整理存档文件">
                      <el-switch
                        v-model="form_4.value3"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="整理存档文件最大内存使用率">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="提示磁盘空间不足">
                      <el-switch
                        v-model="form_4.value4"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="最低可用磁盘空间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="磁盘最大使用率">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="自动移动存档文件时间">
                      <el-input placeholder="请输入" value="0" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="系统安全" name="系统安全">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用日志输出">
                      <el-switch
                        v-model="form_5.value1"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用日志加密">
                      <el-switch
                        v-model="form_5.value2"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用登录次数验证">
                      <el-switch
                        v-model="form_5.value3"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用用户详细日志">
                      <el-switch
                        v-model="form_5.value4"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="启用日志覆盖写功能">
                      <el-switch
                        v-model="form_5.value5"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="数据镜像" name="数据镜像">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像模式">
                      <el-select placeholder="请选择" v-model="form_6.region">
                        <el-option label="镜像发送" value="1" />
                        <el-option label="镜像接受" value="2" />
                        <el-option label="镜像收发" value="3" />
                        <el-option label="独立服务器" value="0" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像发送目标地址">
                      <el-input placeholder="请输入" value="localhost" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像发送目标端口">
                      <el-input placeholder="请输入" value="6328" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像接收端口">
                      <el-input placeholder="请输入" value="6328" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像接收线程数量">
                      <el-input placeholder="请输入" value="10" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像缓存文件上限">
                      <el-input placeholder="请输入" value="100" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像缓存队列容量">
                      <el-input placeholder="请输入" value="50000" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像报文压缩开关">
                      <el-switch
                        v-model="form_6.value1"
                        class="ml-2"
                        style="
                          --el-switch-on-color: #13ce66;
                          --el-switch-off-color: #ff4949;
                        "
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像报文压缩类型">
                      <el-select placeholder="请选择" v-model="form_6.region2">
                        <el-option label="snappy" value="0" />
                        <el-option label="lz4" value="1" />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像报文压缩最小值">
                      <el-input placeholder="请输入" value="1000" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="网络隔离装号ACK字节">
                      <el-input placeholder="请输入" value="255" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="系统文件" name="系统文件">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="点表配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\table.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="基本点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\baseex.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="计算点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\calc.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="标签点关键属性信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys base.xml"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="采集点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\scan.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="标签点快照配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\snapshot.xml"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="回收站中基本点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys baserecycle.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="回收站中采集点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\scanrecycle.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="回收站中标签点快照事件信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\syssnaprecycle.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="存档文件配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys hisinfo.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="用户权限配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sysuser.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="回收站中计算点配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\calcrecycle.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="网络交互内存映射文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\calcrecycle.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="网络交互内存映射文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\server.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="方程式交互内存映射文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\equation.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="历史数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\arvbuf.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补历史数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\arvexbuf.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="BLOB/STRING补历史数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\arvexblobbuf.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="历史数据交换页文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\swappage.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="信任连接配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\swappage.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="黑名单配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\firewall.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="授权协议信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\license.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="白定义类型配置信息">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sys\type.xml"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="镜像数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\mirror.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补写镜像数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\mirrorex.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="BLOB/STRING镜像数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\sysstrblobmirror.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="补写BLOB/STRING镜像数据缓存文件">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\sys\strblobmirror.dat"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="数据库日志路径">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Files\golden\log"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="方程式文件路径">
                      <el-input
                        placeholder="请输入"
                        value="D:\Program Filesgolden\exp"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="数据同步缓存文件">
                      <el-input placeholder="请输入" value="" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="数据同步补写数据缓存文件">
                      <el-input placeholder="请输入" value="" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="数据同步BLOB/STRING数据缓存文件">
                      <el-input placeholder="请输入" value="" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>

            <el-tab-pane label="许可协议" name="许可协议">
              <el-form :model="form" label-width="auto" label-position="left">
                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可点表数">
                      <el-input placeholder="请输入" value="1000" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可标签点数">
                      <el-input placeholder="请输入" value="100万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可采集点数">
                      <el-input placeholder="请输入" value="100万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可计算点数">
                      <el-input placeholder="请输入" value="1万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可字符串和BLOB点数">
                      <el-input placeholder="请输入" value="1万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可历史存档数">
                      <el-input placeholder="请输入" value="1万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可回收站容量">
                      <el-input placeholder="请输入" value="100万" />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="12">
                    <el-form-item label="许可用户连接数">
                      <el-input placeholder="请输入" value="500" />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-tab-pane>
      <el-tab-pane label="客户端设置" name="clientConfig">
        <el-card>
          <el-tabs
            v-model="clientLeftActive"
            tab-position="left"
            class="demo-tabs"
          >
            <el-tab-pane label="基本配置" name="基本配置">User</el-tab-pane>
          </el-tabs>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, watch, reactive } from "vue";
import { ElMessage } from "element-plus";

const activeName = ref("serverConfig");

const serverLeftActive = ref("服务配置");
const clientLeftActive = ref("基本配置");
const form_2 = reactive({
  region: "0",
  value1: true,
  value2: true,
});

const form_3 = reactive({
  region: "0",
  value1: true,
  value2: true,
  value3: true,
  value4: true,
  value5: true,
  value6: true,
  value7: true,
});

const form_4 = reactive({
  region: "0",
  value1: true,
  value2: true,
  value3: true,
  value4: true,
});

const form_5 = reactive({
  value1: true,
  value2: true,
  value3: true,
  value4: true,
  value5: true,
});

const form_6 = reactive({
  region: "0",
  region2: "0",
  value1: true,
  value2: true,
  value3: true,
  value4: true,
  value5: true,
});
</script>

<style lang="scss" scoped>
:deep(.el-input-number .el-input__inner) {
  text-align: left;
}

:deep(.el-form) {
  padding-left: 25px;
  height: 80vh;
  overflow-x: hidden; /* 水平方向上的内容被裁剪 */
  overflow-y: auto; /* 垂直方向上显示滚动条 */
}
</style>
