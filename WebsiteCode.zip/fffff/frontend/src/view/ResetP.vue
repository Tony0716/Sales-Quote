<script setup>
import { reactive } from "vue";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();
const jump = () => {
  router.back();
};
const form = reactive({
  email: "",
});

const restp = () => {
  if (!checkEmail(form.email)) {
    ElMessage({
      message: "Please enter the correct email addresseckEmail",
      type: "warning",
    });
  } else {
    axios.post("/resetp", {
      email: form.email,
    })
    .then((response) => {
      // Handle the response from the backend here
      if (response.data.message === "Email Sent") {
        ElMessage({
          message: "Please check your email for your password",
          type: "success",
        })
        router.push("/changep");
      }else if (response.data.message === "Email Not Found"){
        ElMessage({
          message: "Email Not Found",
          type: "error",
        })}
       else {
        ElMessage({
          message: "An error occurred",
          type: "error",
        });
      }
    })
    .catch((error) => {
      console.error(error);
      ElMessage({
        message: "Connection Error",
        type: "error",
      });
    });
  }
};
// 使用正则表达式来检查邮箱格式
const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
const checkEmail = (email) => {
  if (email == "") {
    return false;
  }
  return emailRegex.test(email);
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-main>
          <div class="title">Forgot Password</div>
          <el-row :gutter="20">
            <el-col :span="6" :offset="9">
              <el-form :model="form" label-position="top" size="large">
                <el-form-item label="Email">
                  <el-input v-model="form.email" placeholder="name@email.com" />
                </el-form-item>
                <el-form-item>
                  <el-button
                    size="large"
                    @click="restp"
                    style="
                      width: 100%;
                      background: #767171;
                      color: #fff;
                      height: 50px;
                      font-weight: bold;
                      font-size: 15px;
                    "
                  >
                    Reset Password
                  </el-button>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="back" @click="jump">Back to sign in</div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    justify-content: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;
  }
  .el-main {
    padding-top: 80px;
    height: calc(100vh - 99px);
    .title {
      font-size: 48px;
      padding-top: 100px;
      padding-bottom: 70px;
      font-weight: bold;
      margin: 0 auto;
      text-align: center;
    }
    .back {
      padding-top: 90px;
      margin: 0 auto;
      text-align: center;
      cursor: pointer;
      font-size: large;
    }
  }
}
:deep(.el-form) {
  .el-form-item .el-form-item__label {
    font-size: large;
    color: black;
  }

  .el-input__inner {
    height: 50px !important;
  }
}
</style>
