<script setup>
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();
const login = sessionStorage.getItem("login");
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");
var isShowing = false;

if (role === "admin") {
  isShowing = true;
}

if (!login || !token) {
  router.push("/login");
}

axios
  .get("/token", { headers: { "x-auth-token": token } })
  .then((response) => {
    if (response.data.message !== "Permitted") {
      router.push("/access-denied");
    }
    form.tokens = response.data.rows;
    console.log(form.tokens);
  })
  .catch((error) => {
    ElMessage({
      message: "Connection Error",
      type: "error",
    });
  });

const jump_2 = () => {
  router.push("/token");
};

const jump_1 = () => {
  router.push("/");
};
const jump_3 = () => {
  router.push("/upload");
};
const jump_4 = () => {
  router.push("/manageAccount");
};

const form = reactive({
  text: "",
  role: "user",
  tokens: [],
});

const restp = () => {
  if (form.text == "") {
    ElMessage({
      message: "The Text cannot be empty",
      type: "warning",
    });
  } else {
    axios
      .post("/token", {
        token: form.text,
        role: form.role,
        jwt_token: token,
      })
      .then((response) => {
        if (response.data.message === "Token alredy exist") {
          ElMessage({
            message: "Token alredy exist",
            type: "error",
          });
        } else if (response.data.message === "Successful") {
          ElMessage({
            message: "Token Generated",
            type: "success",
          });
          location.reload();
        } else {
          ElMessage({
            message: "Unknown Error",
            type: "error",
          });
        }
      })
      .catch((error) => {
        ElMessage({
          message: "Connection Error",
          type: "error",
        });
      });
  }
};

const deleteToken = (Token) => {
  axios.delete("/token", { params: { token: Token } }).then((response) => {
    if (response.data.message === "Successful") {
      ElMessage({
        message: "Token deleted successfully",
        type: "success",
      });
      location.reload();
    }
  });
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-aside width="200px">
          <div class="title" @click="jump_1">Sales Quote</div>
          <div class="title active" v-show="isShowing" @click="jump_2">
            Create Token
          </div>
          <div class="title" v-show="isShowing" @click="jump_3">Upload</div>
          <div class="title" v-show="isShowing" @click="jump_4">Manage Account</div>
        </el-aside>
        <el-container>
          <el-main>
            <el-form :model="form" label-position="top" size="large">
              <el-row :gutter="20">
                <el-col :span="10">
                  <el-form-item label="Text box">
                    <el-input v-model="form.text" />
                  </el-form-item>
                </el-col>
                <el-col :span="10">
                  <el-form-item label="Select Role:">
                    <el-select v-model="form.role" id="roleSelect">
                      <el-option label="Admin" value="admin"></el-option>
                      <el-option label="User" value="user"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="12">
                  <el-form-item>
                    <el-button
                      size="large"
                      @click="restp"
                      style="
                        width: 25%;
                        background: #767171;
                        color: #fff;
                        height: 50px;
                        font-weight: bold;
                        font-size: 15px;
                        margin: 0 auto;
                      "
                    >
                      Submit
                    </el-button>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <table class="el-table my-table">
              <thead>
                <tr>
                  <th>Token</th>
                  <th>Role</th>
                  <th>Create Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="t in form.tokens" :key="t.token">
                  <td>{{ t.token }}</td>
                  <td>{{ t.role }}</td>
                  <td>{{ t.createDate }}</td>
                  <td>{{ t.status }}</td>
                  <td>
                    <el-button
                      type="danger"
                      size="mini"
                      @click="deleteToken(t.token)"
                      >Delete</el-button
                    >
                  </td>
                </tr>
              </tbody>
            </table>
          </el-main>
          <el-footer>Footer</el-footer>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    border: 1px solid #40525c;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;

    .title {
      height: 25px;
      font-weight: bold;
      margin-bottom: 35px;
      border-bottom: 2px solid transparent;
      &:last-of-type {
        margin-bottom: 0;
      }
      &.active {
        border-bottom-color: #0089d2;
        color: #0089d2;
      }
    }
  }
  .el-main {
    border-left: 3px solid #40525c;
    background-color: #ffffff;

    .my-table {
      border-collapse: collapse;
      border: 1px solid #ccc;
      text-align: center;
    }

    .my-table th,
    .my-table td {
      border: 1px solid #ccc;
      padding: 8px;
    }

    .my-table th {
      background-color: #f2f2f2;
      font-weight: bold;
    }
  }
  .el-footer {
    border-left: 3px solid #40525c;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
  }
}
</style>
