<script setup>
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();
const login = sessionStorage.getItem("login");
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");
var isShowing = false;

if (role === "admin") {
  isShowing = true;
}

if (!login || !token) {
  router.push("/login");
}

const form = reactive({
  users: [],
});

axios
  .get("/manageAccount", { headers: { "x-auth-token": token } })
  .then((response) => {
    if (response.data.message !== "Permitted") {
      router.push("/access-denied");
    }
    form.users = response.data.rows;
    console.log(form.users);
  })
  .catch((error) => {
    ElMessage({
      message: "Connection Error",
      type: "error",
    });
  });

const jump_2 = () => {
  router.push("/token");
};

const jump_1 = () => {
  router.push("/");
};
const jump_3 = () => {
  router.push("/upload");
};
const jump_4 = () => {
  router.push("/manageAccount");
};

const deleteToken = (email) => {
  axios.delete("/manageAccount", { params: { email: email } }).then((response) => {
    if (response.data.message === "Successful") {
      ElMessage({
        message: "User deleted successfully",
        type: "success",
      });
      location.reload();
    }
  });
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-aside width="200px">
          <div class="title" @click="jump_1">Sales Quote</div>
          <div class="title" v-show="isShowing" @click="jump_2">
            Create Token
          </div>
          <div class="title" v-show="isShowing" @click="jump_3">Upload</div>
          <div class="title active" v-show="isShowing" @click="jump_4">Manage Account</div>
        </el-aside>
        <el-container>
          <el-main>
            <table class="el-table my-table">
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="t in form.users" :key="t.email">
                  <td>{{ t.firstName }}</td>
                  <td>{{ t.lastName }}</td>
                  <td>{{ t.role }}</td>
                  <td>
                    <el-button
                      type="danger"
                      size="mini"
                      @click="deleteToken(t.email)"
                      >Delete</el-button
                    >
                  </td>
                </tr>
              </tbody>
            </table>
          </el-main>
          <el-footer>Footer</el-footer>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    border: 1px solid #40525c;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;

    .title {
      height: 25px;
      font-weight: bold;
      margin-bottom: 35px;
      border-bottom: 2px solid transparent;
      &:last-of-type {
        margin-bottom: 0;
      }
      &.active {
        border-bottom-color: #0089d2;
        color: #0089d2;
      }
    }
  }
  .el-main {
    border-left: 3px solid #40525c;
    background-color: #ffffff;

    .my-table {
      border-collapse: collapse;
      border: 1px solid #ccc;
      text-align: center;
    }

    .my-table th,
    .my-table td {
      border: 1px solid #ccc;
      padding: 8px;
    }

    .my-table th {
      background-color: #f2f2f2;
      font-weight: bold;
    }
  }
  .el-footer {
    border-left: 3px solid #40525c;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
  }
}
</style>
