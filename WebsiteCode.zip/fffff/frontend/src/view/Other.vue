<script setup>
import { ref, computed, reactive, nextTick } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";
import { ElMessage } from "element-plus";
const login = sessionStorage.getItem("login");
const token = localStorage.getItem("token");

if (!login || !token) {
  router.push("/login");
}

const store = useStore();
const router = useRouter();
const Data = computed(() => store.state.userAbout.modelSelect); //获取store数据 页面刷新store数据不会丢失
const displayData = computed(() => store.state.userAbout.userSelections);
console.log({ displayData });

const deliveryType = ref("ExWorks - Shady Grove, PA");
const deliveryOptions = [
  "ExWorks - Shady Grove, PA",
  "CIF - East Coast Port",
  "CIF - West Coast Port",
];

const disconut = ref({
  masts: 0,
  upper: 0,
});

const totalPrice = ref({
  upper: "0.00",
  masts: "0.00",
  total: "0.00",
});

const updateTotalPrice = () => {
  const upper =
    (displayData.value.specific.reduce(
      (pre, cur) => pre + Number(cur.price),
      0
    ) +
      displayData.value.crane.price) *
    (1 - disconut.value.upper * 0.01);
  const masts =
    displayData.value.common.reduce((pre, cur) => pre + Number(cur.price), 0) *
    (1 - disconut.value.masts * 0.01);

  totalPrice.value.upper = upper.toFixed(2);
  totalPrice.value.masts = masts.toFixed(2);
  totalPrice.value.total = (upper + masts + Number(oceanFright.value)).toFixed(
    2
  );
};

function onDelete(type, index) {
  store.commit("userAbout/EDIT__USERS_ELECT", {
    type,
    operation: "delete",
    index,
  });
}
const isShowAddInput = ref({
  common: true,
  specific: true,
});
const tempText = ref({
  common: "",
  specific: "",
});

function onAdd(type) {
  isShowAddInput.value[type] = false;
}
async function onComfirmAdd(type) {
  if (!tempText.value[type]) {
    ElMessage.error("Empty Text!");
  } else {
    store.commit("userAbout/EDIT__USERS_ELECT", {
      type,
      operation: "add",
      text: tempText.value[type],
    });

    await nextTick();
    isShowAddInput.value[type] = true;
    tempText.value[type] = "";
  }
}
const special = ref("");
const formInline = reactive({
  user: "",
  to: "",
  to1: "",
  subject: "",
});
const formInline1 = reactive({
  input1: "",
  input2: "",
  input3: "",
  input4: "",
  input5: "",
});

const techForm = ref(["", "", ["", "", ""], ["", ""], ["", ""]]);
const printObj = ref({
  id: "printMe",
  closeCallback() {
    isPrintMode.value = false;
  },
});
const oceanFright = ref(null);
// 初始化计算属性
updateTotalPrice();
// 计算属性
const trendsTotal = computed(() => {
  const upper = parseFloat(totalPrice.value.upper);
  const masts = parseFloat(totalPrice.value.masts);
  const oceanFrightValue = parseFloat(oceanFright.value || 0);
  return (upper + masts + oceanFrightValue).toFixed(2);
});
const isPrintMode = ref(false);
async function onPrint() {
  isPrintMode.value = true;
}

const jump = () => {
  router.back();
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-aside width="100px"></el-aside>
        <el-container>
          <el-main>
            <div class="title_box">
              <div class="model">Crane Model</div>
              <div class="text">{{ Data }}</div>
            </div>
            <div class="pdf" id="printMe">
              <div class="top-pdf">
                <div class="top-left">
                  <img src="../assets/logopdf.png" alt="" />
                </div>
                <div class="top-right">
                  <p class="fw-bold">Manitowoc Cranes</p>
                  <p>One Park Plaza</p>
                  <p>11270 West Park Place</p>
                  <p>Milwaukee, WI 53224</p>
                  <p>T 414 760 4600</p>
                  <p>www.manitowoc.com</p>
                </div>
              </div>
              <div class="twodiv">
                <div class="div-left">
                  <p>Date</p>
                  <p>{{ formInline.date }}</p>
                  <p>To</p>
                  <p>{{ formInline.to }}</p>
                  <p>{{ formInline.to1 }}</p>
                  <p>Subject</p>
                  <p>{{ formInline.subject }}</p>
                </div>
                <div class="div-right">
                  <p>From</p>
                  <p>{{ formInline1.input1 }}</p>
                  <p>{{ formInline1.input2 }}</p>
                  <p>{{ formInline1.input3 }}</p>
                  <p>{{ formInline1.input4 }}</p>
                  <p>M: {{ formInline1.input5 }}</p>
                </div>
              </div>
              <div class="Technical">
                <p>
                  Please find below our proposal for a New Potain
                  {{ displayData.model }} Top Slewing, Tower Crane (Crane #3)
                  including:
                </p>
              </div>
              <div class="Technical">
                <p>Technical Specifications:</p>
                <ul v-show="!isPrintMode">
                  <li>
                    <el-input v-model="techForm[0]" class="input-box" /> maximum
                    capacity
                  </li>
                  <li>
                    Maximum radius of
                    <el-input v-model="techForm[1]" class="input-box" />
                  </li>
                  <li>
                    Maximum load:
                    <el-input v-model="techForm[2][0]" class="input-box" /> at
                    <el-input v-model="techForm[2][1]" class="input-box" /> with
                    <el-input v-model="techForm[2][2]" class="input-box" /> jib
                  </li>
                  <li>
                    Maximum load at
                    <el-input v-model="techForm[3][0]" class="input-box" />:
                    <el-input v-model="techForm[3][1]" class="input-box" />
                  </li>
                  <li>
                    Power supply:
                    <el-input v-model="techForm[4][0]" class="input-box" /> (+6%
                    - 10%) –
                    <el-input v-model="techForm[4][1]" class="input-box" />Hz
                  </li>
                </ul>
                <ul v-show="isPrintMode">
                  <li>{{ techForm[0] }} maximum capacity</li>
                  <li>Maximum radius of {{ techForm[1] }}</li>
                  <li>
                    Maximum load: {{ techForm[2][0] }} at
                    {{ techForm[2][1] }} with {{ techForm[2][2] }} jib
                  </li>
                  <li>
                    Maximum load at {{ techForm[3][0] }}: {{ techForm[3][1] }}
                  </li>
                  <li>
                    Power supply: {{ techForm[4][0] }} (+6% - 10%) –
                    {{ techForm[4][1] }}
                  </li>
                </ul>
              </div>
              <div class="Technical">
                <p>Masts & Accessories:</p>
                <ul>
                  <li
                    v-for="(item, index) in displayData.common"
                    :key="item.label + index"
                  >
                    <span>{{ item.label }}</span>
                    <el-icon
                      v-show="!isPrintMode"
                      @click="() => onDelete('common', index)"
                    >
                      <Close />
                    </el-icon>
                  </li>
                  <li class="hide-circle">
                    <el-icon
                      class="add-icon"
                      @click="() => onAdd('common')"
                      v-show="isShowAddInput.common && !isPrintMode"
                    >
                      <Plus />
                    </el-icon>
                    <div v-show="!isShowAddInput.common && !isPrintMode">
                      <el-input
                        v-model="tempText.common"
                        style="width: 200px"
                      ></el-input>
                      <el-button @click="() => onComfirmAdd('common')"
                        >Add</el-button
                      >
                    </div>
                  </li>
                </ul>
              </div>
              <div class="Technical">
                <p>Upper Works:</p>
                <ul>
                  <li
                    v-for="(item, index) in displayData.specific"
                    :key="item.label + index"
                  >
                    <span>{{ item.label }}</span>
                    <el-icon
                      v-show="!isPrintMode"
                      @click="() => onDelete('specific', index)"
                    >
                      <Close />
                    </el-icon>
                  </li>
                  <li class="hide-circle">
                    <el-icon
                      class="add-icon"
                      @click="() => onAdd('specific')"
                      v-show="isShowAddInput.specific && !isPrintMode"
                    >
                      <Plus />
                    </el-icon>
                    <div v-show="!isShowAddInput.specific && !isPrintMode">
                      <el-input
                        v-model="tempText.specific"
                        style="width: 200px"
                      ></el-input>
                      <el-button @click="() => onComfirmAdd('specific')"
                        >Add</el-button
                      >
                    </div>
                  </li>
                </ul>
              </div>
              <div class="Technical totals">
                <div class="unique">
                  <p>Total for Crane Upper Works:</p>
                  <p>${{ totalPrice.upper }}</p>
                </div>
                <div class="unique">
                  <p>Total for Masts & Accessories:</p>
                  <p>${{ totalPrice.masts }}</p>
                </div>
                <div class="unique">
                  <p>Ocean Freight:</p>
                  <el-input
                    v-model="oceanFright"
                    style="width: 100px"
                    v-show="!isPrintMode"
                  ></el-input>
                  <p v-show="isPrintMode">$ {{ oceanFright }}9999</p>
                </div>
                <div class="unique">
                  <p>Total:</p>
                  <p>${{ trendsTotal }}</p>
                </div>
              </div>
              <div class="Technical">
                <p>Delivery terms:</p>
                <ul>
                  <li style="margin-bottom: 10px" v-show="!isPrintMode">
                    <el-select v-model="deliveryType" style="width: 300px">
                      <el-option
                        v-for="item in deliveryOptions"
                        :key="item"
                        :label="item"
                        :value="item"
                      ></el-option>
                    </el-select>
                  </li>
                  <p v-show="isPrintMode">
                    {{ deliveryType }}
                  </p>
                </ul>
              </div>
              <div class="Technical">
                <p>Terms & Conditions:</p>
                <ul>
                  <li>Ship and invoice as available</li>
                  <li>Warranty – 12 months, parts & labor.</li>
                  <li>All prices are in U.S. Dollars.</li>
                  <li>Prices valid for 30 days from effective date.</li>
                  <li>Terms: Net 30 days upon credit approval.</li>
                  <li>
                    Prices do not include any taxes or tariffs that, if
                    applicable, are the purchaser's responsibility.
                  </li>
                  <li>
                    The purchaser is responsible for all freight and ancillary
                    costs from ExWorks and CIF points.
                  </li>
                  <li>
                    Quoted values for ocean freight are estimates and an
                    adjusted amount could be billed.
                  </li>
                  <li>
                    Machinery must be removed from our inventory within 30 days
                    of availability.
                  </li>
                  <li>
                    All claims regarding machine composition must be made within
                    60 days of pick up by customer.
                  </li>
                  <li>
                    Quotation does not include any ancillary items or services.
                  </li>
                  <li>The purchaser is responsible for any demurrage.</li>
                  <li>
                    Service, erection, and warranty per current Manitowoc Crane
                    Care policy.
                  </li>
                  <li>
                    Any additional options will be invoiced upon availability to
                    the purchaser.
                  </li>
                  <li>Subject to prior sale.</li>
                  <li>
                    Click for a complete list of current
                    <a href="./pdf.pdf"
                      >Manitowoc Terms and Conditions of Sale</a
                    >.
                  </li>
                </ul>
              </div>
            </div>
          </el-main>
          <div class="form" style="margin: 50px 0">
            <h1>Editleft</h1>
            <el-form
              :inline="true"
              :model="formInline"
              class="demo-form-inline"
            >
              <el-form-item label="date">
                <el-date-picker
                  v-model="formInline.date"
                  type="date"
                  format="MMM D,YYYY"
                  value-format="MMM D,YYYY"
                  placeholder="Pick a date"
                  clearable
                />
              </el-form-item>
              <el-form-item label="to">
                <el-input
                  v-model="formInline.to"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="to1">
                <el-input
                  v-model="formInline.to1"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="subject">
                <el-input
                  v-model="formInline.subject"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
            </el-form>
          </div>
          <div class="form" style="margin: 50px 0">
            <h1>Editright</h1>
            <el-form
              :inline="true"
              :model="formInline1"
              class="demo-form-inline"
            >
              <el-form-item label="input1">
                <el-input
                  v-model="formInline1.input1"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="input2">
                <el-input
                  v-model="formInline1.input2"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="input3">
                <el-input
                  v-model="formInline1.input3"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="input4">
                <el-input
                  v-model="formInline1.input4"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
              <el-form-item label="input5">
                <el-input
                  v-model="formInline1.input5"
                  placeholder="Approved by"
                  clearable
                />
              </el-form-item>
            </el-form>
          </div>
          <div class="form" style="margin: 50px 0">
            <h1>Edit Discount</h1>
            <el-form :inline="true" class="demo-form-inline">
              <el-form-item label="Masts & Accessories Disconut(%)">
                <el-input
                  v-model="disconut.masts"
                  placeholder="Disconut"
                  clearable
                />
              </el-form-item>
              <el-form-item label="Upper Works Disconut(%)">
                <el-input
                  v-model="disconut.upper"
                  placeholder="Disconut"
                  clearable
                />
              </el-form-item>
            </el-form>
          </div>
          <el-footer>
            <div class="group">
              <div class="btn" @click="jump">Edit</div>
              <div class="btn" @click="onPrint">Generate PDF</div>
            </div>
          </el-footer>
        </el-container>
      </el-container>
    </el-container>
    <el-dialog v-model="isPrintMode" title="Confirm">
      Are sure you want to print?
      <template #footer>
        <el-button>Cancel</el-button>
        <el-button type="primary" v-print="printObj">OK</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped lang="scss">
body {
  font-family: "Times New Roman", Times, serif !important;
}
.hide-circle::marker {
  content: "";
}
.input-box {
  width: 50px !important;
}

.Delivery {
  p {
    font-weight: 600;
    font-size: 16px;
    margin: 10px 0;
  }

  p:nth-child(2) {
    font-weight: normal;
    font-size: 16px;
    margin: 10px 20px;
  }
}

.bolder {
  font-weight: 600;
  font-size: 16px;
  margin-top: 10px;
}

.prise {
  p {
    text-align: end;
    font-weight: 600;
    font-size: 16px;
    margin-top: 10px;

    span {
      width: 100px;
      display: inline-block;
    }
  }
}

.Terms {
  p {
    font-weight: 600;
    font-size: 16px;
    margin: 10px 0;
  }

  ul {
    padding-left: 30px;
  }
}

.totals {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.Technical {
  li {
    display: list-item;
    align-items: center;
    position: relative;
    font-size: 16px;

    .el-icon {
      cursor: pointer;
    }
    .add-icon {
      position: absolute;
      left: -20px;
    }
    .el-button {
      margin-left: 10px;
    }
  }

  .unique {
    width: 600px;
    display: flex;
    justify-content: space-between;

    p {
      margin: 0;
    }

    p:first-child {
      width: 450px;
      text-align: right;
    }

    p:last-child {
      width: 100px;
      text-align: right;
    }
  }

  p {
    font-weight: 600;
    font-size: 16px;
    margin: 10px 0;
  }

  ul {
    padding-left: 30px;

    p {
      font-weight: normal;
      font-size: 15px;
    }
  }
}

.Upper {
  p {
    font-weight: 600;
    font-size: 16px;
    margin: 10px 0;
  }

  ul {
    padding-left: 30px;
  }
}

.Masts {
  p {
    font-weight: 600;
    font-size: 16px;
    margin: 10px 0;
  }

  ul {
    padding-left: 30px;
  }
}

.pdf {
  width: 100%;
  margin-bottom: 20px;

  .top-pdf {
    display: flex;

    .top-left {
      flex: 1;

      img {
        width: 50%;
      }
    }

    .top-right {
      flex: 1;
      display: flex;
      flex-direction: column;
      padding-left: 30%;

      .fw-bold {
        font-weight: 600;
      }
    }
  }

  .twodiv {
    display: flex;
    margin-top: 20px;

    .div-left {
      margin-right: 50px;
      border-left: 2px solid black;
      border-top: 2px solid black;
      padding: 10px;
      flex: 1;

      p:nth-child(1) {
        font-size: 16px;
      }

      p:nth-child(3) {
        font-size: 16px;
      }

      p:nth-child(6) {
        font-size: 16px;
      }
    }

    .div-right {
      margin-right: 50px;
      padding: 10px;
      border-left: 2px solid black;
      border-top: 2px solid black;
      flex: 1;

      p:nth-child(1) {
        font-size: 16px;
      }

      p:nth-child(5) {
        color: blue;
        text-decoration: underline;
      }
    }
  }
}

.common-layout {
  font-family: "Times New Roman", Times, serif !important;
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;

    img {
      width: 220px;
    }
  }

  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    justify-content: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;
  }

  .el-main {
    padding-top: 80px;
    background-color: #ffffff;

    .title_box {
      display: flex;
      align-items: center;
      margin-bottom: 50px;

      .model {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 7px;
        font-size: small;
        border: 2px solid black;
        margin-right: 20px;
      }

      .text {
        font-weight: bold;
      }
    }
  }

  .el-footer {
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
    padding-bottom: 80px;

    .group {
      width: 80%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      padding-bottom: 50px;
      border-bottom: 3px solid #ed1d2a;

      .btn {
        &:first-of-type {
          margin-right: 100px;
        }

        &:last-of-type {
          margin-left: 100px;
        }
      }
    }
  }
}
</style>
