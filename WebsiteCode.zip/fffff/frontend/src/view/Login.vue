<script setup>
import { reactive } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();

const form = reactive({
  name: "",
  password: "",
});

const logOn = () => {
  if (form.name == "") {
    ElMessage({
      message: "User cannot be empty",
      type: "warning",
    });
  } else if (form.password == "") {
    ElMessage({
      message: "The user password cannot be empty",
      type: "warning",
    });
  } else {
    // Send a login request to the backend
    axios.post("/login", {
      email: form.name,
      password: form.password,
    })
    .then((response) => {
      // Handle the response from the backend here
      if (response.data.message === "Login successful") {
        // Redirect to the home page upon successful login

        localStorage.setItem('token', response.data.jwt);
        localStorage.setItem('role', response.data.role);
        sessionStorage.setItem('login', 'true');

        router.push("/");
      }else if (response.data.message === "Login failed. Email not verified"){
        ElMessage({
          message: "Please Verify your Account",
          type: "error",
        })}
       else {
        ElMessage({
          message: "Login failed; Incorrect email or password",
          type: "error",
        });
      }
    })
    .catch((error) => {
      console.error(error);
      ElMessage({
        message: "Connection Error",
        type: "error",
      });
    });
  }
};

const jump = (url) => {
  router.push(url);
};
</script>

<template>
  <div style="position: relative">
    <div style="display: flex; margin-left: 200px; margin-top: 40px">
      <img src="../assets/1.png" alt="" />
    </div>
    <div
      style="
        font-size: 40px;
        font-weight: 700;
        margin-top: 100px;
        margin-left: 440px;
      "
    >
      Manitowoc Direct
    </div>
    <div style="margin: 40px auto; width: 1000px; position: relative">
      <el-form :model="form" label-width="120px">
        <el-form-item>
          <div style="display: flex; width: 100%">
            <div
              style="
                display: inline-block;
                width: 200px;
                font-size: 20px;
                height: 50px;
                line-height: 50px;
                color: gray;
                margin-right: 150px;
              "
            >
              User Account
            </div>
            <el-input v-model="form.name" placeholder="some@example.com" />
          </div>
        </el-form-item>
        <el-form-item label-position="left">
          <div style="display: flex; width: 100%">
            <div
              style="
                display: inline-block;
                width: 200px;
                font-size: 20px;
                height: 50px;
                line-height: 50px;
                color: gray;
                margin-right: 150px;
              "
            >
              Password
            </div>
            <el-input
              type="password"
              show-password
              v-model="form.password"
              placeholder="Password"
            />
          </div>
        </el-form-item>
      </el-form>
      <el-button
        size="large"
        style="position: absolute; right: 0px; margin-top: 10px"
        @click="logOn"
        >sign in</el-button>
    </div>

    <div
      style="
        display: flex;
        margin: 100px auto 40px;
        width: 800px;
        color: gray;
        justify-content: space-around;
      "
    >
      <div
        style="border-right: 2px solid gray; width: 200px; cursor: pointer"
        @click="jump('/changep')"
      >
        Change Password
      </div>
      <div
        style="border-right: 2px solid gray; width: 200px; cursor: pointer"
        @click="jump('/resetp')"
      >
        Forget Password
      </div>
      <!-- <div style="width: 200px">Requset an Account</div> -->
      <div style="width: 200px; cursor: pointer" @click="jump('/signup')">
        Sign Up
      </div>
    </div>
    <div
      style="
        font-size: 30px;
        color: gray;
        position: absolute;
        width: 500px;
        transform: translatex(-50%);
        left: 50%;
        text-align: center;
      "
    >
      Manitowoc Website Home Page
    </div>
    <div
      style="
        font-size: 30px;
        position: absolute;
        width: 1300px;
        transform: translatex(-50%);
        left: 50%;
        margin-top: 40px;
      "
    >
      If you are experiencing problems or are in need of assistance please click
      here to contact Manitowoc Direct support.
    </div>
    <div style="width: 1400px; margin: 250px auto 0px">
      <div style="height: 4px; background: #ef2e3a; width: 100%"></div>
      <div style="display: flex; margin-top: 10px">
        <div>2019 Manitowoc</div>
        <div style="margin: 0 10px">|</div>
        <div>all rights reserved</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
::v-deep .asterisk-left {
  margin-left: 0px !important;
  justify-content: space-around !important;
}
::v-deep .asterisk-left label {
  margin-right: 200px;
  padding-left: 0px !important;
  margin-left: 0px !important;
  font-size: 20px;
  width: 170px !important;
}
:v-deep #el-id-6825-1 {
}
::v-deep .el-input__inner {
  height: 50px !important;
}
</style>
