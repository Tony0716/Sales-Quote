<script setup>
import { ref, reactive, onMounted } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from 'element-plus';
import axios from "axios";

const router = useRouter();
const login = sessionStorage.getItem("login");
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");
var isShowing = false;

if (role === "admin") {
  isShowing = true;
}


if (!login || !token) {
  router.push("/login");
}

const jump_1 = () => {router.push("/");};
const jump_2 = () => {
  router.push("/token");
};
const jump_3 = () => {
  router.push("/upload");
};
const jump_4 = () => {
  router.push("/manageAccount");
};

const form = reactive({ 
  role: "user"});

const currentFile = ref();

function handleFileChange(file, fileList) {
  // Capture the latest file
  currentFile.value = fileList.length > 0 ? fileList[fileList.length - 1] : null;
}

const submitUpload = async () => {
  if (!currentFile.value) {
    ElMessage.error('No file selected.');
    return;
  }

  const formData = new FormData();
  formData.append('file', currentFile.value.raw);

  // ... Axios upload logic ...
  try {
    const response = await axios.post('/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    ElMessage.success('File uploaded successfully');
    console.log(response.data);
  } catch (error) {
    ElMessage.error(`Error in file upload: ${error.message}`);
    console.error('Error uploading the file:', error);
  }
};
</script>


<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-aside width="200px">
          <div class="title" @click="jump_1">Sales Quote</div>
          <div class="title" v-show="isShowing" @click="jump_2">
            Create Token
          </div>
          <div class="title active" v-show="isShowing" @click="jump_3">Upload</div>
          <div class="title" v-show="isShowing" @click="jump_4">Manage Account</div>
        </el-aside>
        <el-container>
          <el-main>
            <el-form :model="form" label-position="top" size="large">
              <el-row :gutter="20">
                <el-col :span="10">
                <!-- 
                    action: 请求 URL
                    multiple: 是否支持多选文件
                    drag: 是否启用拖拽上传
                    accept: 接受上传的文件类型
                 -->
                  <el-upload
                    class="upload-demo"
                    action
                    @change="handleFileChange"
                    drag
                    :auto-upload="false"
                    :limit="1"
                    :accept="'.csv'"
                  >
                    <el-icon class="el-icon--upload"><upload-filled /></el-icon>
                    <div class="el-upload__text">
                      Drop file here or <em>click to upload</em>
                    </div>
                    <template #tip>
                      <div class="el-upload__tip">
                        Only one csv file with a size less than 500kb
                      </div>
                    </template>
                  </el-upload>
                  <el-button type="primary" @click="submitUpload">Upload File</el-button>
                </el-col>
              </el-row>
            </el-form>
          </el-main>
          <el-footer>Footer</el-footer>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    border: 1px solid #40525c;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;

    .title {
      height: 25px;
      font-weight: bold;
      margin-bottom: 35px;
      border-bottom: 2px solid transparent;
      &:last-of-type {
        margin-bottom: 0;
      }
      &.active {
        border-bottom-color: #0089d2;
        color: #0089d2;
      }
    }
  }
  .el-main {
    border-left: 3px solid #40525c;
    background-color: #ffffff;

    .my-table {
      border-collapse: collapse;
      border: 1px solid #ccc;
      text-align: center;
    }

    .my-table th,
    .my-table td {
      border: 1px solid #ccc;
      padding: 8px;
    }

    .my-table th {
      background-color: #f2f2f2;
      font-weight: bold;
    }
  }
  .el-footer {
    border-left: 3px solid #40525c;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
  }
}
</style>
