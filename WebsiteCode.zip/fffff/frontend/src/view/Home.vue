<script setup>
import { ref, watch, computed, reactive, onMounted } from "vue";
import { ElMessage } from 'element-plus';
import { useRouter } from "vue-router";
const router = useRouter();
import axios from "axios";
import { useStore } from "vuex";
const store = useStore();
const displayData = computed(() => store.state.userAbout.userSelections);
const login = sessionStorage.getItem("login");
const role = localStorage.getItem("role");
var isShowing = false;

if (role === "admin") {
  isShowing = true;
}

if (!login) {
  router.push("/login");
}

const selectData = ref({
  model: '', // 第1个下拉框
  cranes:  '', // 第2个下拉框
  specific: {},
  common: {},
})

const form = reactive({
  options: [],
  cranes: [],
  specificOptions: {},
  commonOptions: {},
});

const getLabel = computed(() => (crane, showCount) => `${showCount ? `${crane.Count}-` : ''}${crane.Item_Number}: ${crane.Description}`)

// get model
onMounted(async () => {
  try {
    const response = await axios.get("/model");
    // Process response...
    if (response.data.message === "Successful") {
      form.options = response.data.models;
    }
    else if (response.data.message === "No Data Available") {
      ElMessage({
        message: "No Data Available, Please Upload A File First",
        type: "error",
      });
    }
  } catch (error) {
    // 调试假数据
    form.options = [
      {
        Model: '1'
      },
      {
        Model: '2'
      },
    ]

    console.error(error);
    ElMessage.error("Connection Error");
  }
});


async function onModelChange(value) {
  // fetch data from backend
  axios.post("/getCraneByModel", {
    model: value,
  })
    .then((response) => {
      if (response.data.message === "Successful") {
        form.cranes = response.data.cranes;
      }
      else if (response.data.message === "No Data Available") {
        ElMessage({
          message: "No Data Available, Please check the file you upload",
          type: "error",
        });
      } else {
        ElMessage({
          message: "Connection Error",
          type: "error",
        });
      }
    })
    .catch((error) => {

      // 调试假数据
      form.cranes = [
        {
          Item_Number: 'aaa',
          Description: 'DescriptionDescriptionDescription',
          Price: 1234,
        },
        {
          Item_Number: 'bbb',
          Description: 'DescriptionDescriptionDescription',
          Price: 4321,
        },
      ]

      ElMessage({
        message: "Connection Error",
        type: "error",
      });
    });

  selectData.value.cranes = '';
  selectData.value.specific = {};
  selectData.value.common = {};
}

async function onCranesChange(value) {
  // fetch data from backend
  axios.post("/getSpecificOptionsByCranes", {
    model: selectData.value.model,
    cranes: value,
  })
    .then((response) => {
      if (response.data.message === "Successful") {
        form.specificOptions = response.data.specific;
        form.commonOptions = response.data.common;
      }
      else if (response.data.message === "No Data Available") {
        ElMessage({
          message: "No Data Available, Please check the file you upload",
          type: "error",
        });
      } else {
        ElMessage({
          message: "Connection Error",
          type: "error",
        });
      }
    })
    .catch((error) => {

      // 调试假数据
      const demo = {
        'ELECTRICAL CABLE EXTENSION': [
          {
            Item_Number: 'PE100',
            Price: 6993.29,
            Description: 'LENGTH 15m - WINCHES  9 TO 25 HP',
            Category: 'ELECTRICAL CABLE EXTENSION',
            Type: 'SPECIFIC OPTIONS',
            QuoteDescription: '',
          },
          {
            Item_Number: 'PE120',
            Price: 8652.32,
            Description: 'LENGTH 30m - WINCHES 9 TO 25 HP',
            Category: 'ELECTRICAL CABLE EXTENSION',
            Type: 'SPECIFIC OPTIONS'
          },
          {
            Item_Number: 'PE142',
            Price: 3083.72,
            Description: 'LENGTH 50m - WINCHES 25 & 33 LVF',
            Category: 'ELECTRICAL CABLE EXTENSION',
            Type: 'SPECIFIC OPTIONS'
          }
        ],
        DERRICK: [
          {
            Item_Number: 'TA011',
            Price: 5866.62,
            Description: 'AUXILIARY WINCH for hoist winch 15 to 25 LVF',
            Category: 'DERRICK',
            Type: 'SPECIFIC OPTIONS',
            QuoteDescription: 'Auxiliary winch for service derrick and slewing derrick.',
          }
        ]
      }
      form.specificOptions = JSON.parse(JSON.stringify(demo));
      form.commonOptions = JSON.parse(JSON.stringify(demo));

      ElMessage({
        message: "Connection Error",
        type: "error",
      });
    }).finally(() => {
      ['specificOptions', 'commonOptions'].forEach(key => {
        Object.keys(form[key]).forEach(itemKey => {
          form[key][itemKey] = form[key][itemKey]?.map(item => ({
            ...item,
            Count: 0,
          }));
        })
      })
      console.log(form.specificOptions);
    })

  selectData.value.specific = {};
  selectData.value.common = {};
}
function onClickInput(e) {
  e.stopPropagation();
}
function onAllSelectChange(selected, kind) {
  getOptionsByKind(kind).forEach(([key, value]) => {
    form[`${kind}Options`][key] = value.map(item => {
      if (selected.includes(item.Item_Number)) {
        // 当前选中的值
        item.Count = item.Count ? item.Count + 1 : 1;
      } 
      return {
        ...item,
      }
    })
  })
}
function getOptionsByKind(kind) {
  return kind ? Object.entries(form[kind === 'specific' ? 'specificOptions' : 'commonOptions']) : []
}
const currentOptions = computed(() => kind => getOptionsByKind(kind));

function onNumberChange(value, kind, props, itemKey) {
  if (value === 1 && !selectData.value[kind]?.[props]?.includes(itemKey)) {
    if (selectData.value[kind][props]) {
      selectData.value[kind][props].push(itemKey)
    } else {
      selectData.value[kind][props] = [itemKey];
    }
  } else if (value === 0 && selectData.value[kind]?.[props]?.includes(itemKey)) {
    selectData.value[kind][props] = selectData.value[kind][props].filter(item => item !== itemKey);
  }
}


const jump = () => {
  store.dispatch('userAbout/handleModel', selectData.model) // 跳转到other页面 将数据发送到store
  store.commit('userAbout/SET_USERS_ELECT', {
    model: selectData.value.model,
    crane: {
      value: selectData.value.cranes,
      price: form.cranes.find(item => item.Item_Number === selectData.value.cranes)?.Price,
    },
    specific: {
      selections: selectData.value.specific,
      options: form.specificOptions,
    },
    common: {
      selections: selectData.value.common,
      options: form.commonOptions,
    },
  })
  router.push("/other");
};

const jump_2 = () => {
  router.push("/token");
};

const jump_3 = () => {
  router.push("/upload");
};

const jump_4 = () => {
  router.push("/manageAccount");
};

const activeTab = ref(0);
const tableData = ref([
  {
    firstName: 'a',
    lastName: 'b',
    email: 'xxx',
    role: 'admin',
  },
  {
    firstName: 'a',
    lastName: 'b',
    email: 'xxx',
    role: 'admin',
  },
])
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-aside width="200px">
          <div :class="['title', activeTab === 0 ? 'active' : '']" @click="activeTab = 0">Sales Quote</div>
          <div class="quote-detail" v-show="selectData.model">
            <div class="quote-detail_item">
              <p class="quote-detail_title">Models</p>
              <p class="quote-detail_desc">{{ selectData.model }}</p>
            </div>
            <div class="quote-detail_item" v-show="selectData.cranes">
              <p class="quote-detail_title">Cranes</p>
              <p class="quote-detail_desc">{{ selectData.cranes }}</p>
            </div>
            <div class="quote-detail_item" v-show="Object.keys(selectData.specific)?.length">
              <p class="quote-detail_title">Specific</p>
              <p class="quote-detail_desc" v-for="([key, value]) in Object.entries(selectData.specific)" :key="key">
              <p v-show="value.length > 0">{{ key }}:</p>
              <p v-for="item in value" :key="item" class="quote-detail_child-desc">{{ item }}</p>
              </p>
            </div>
            <div class="quote-detail_item" v-show="Object.keys(selectData.common)?.length">
              <p class="quote-detail_title">Common</p>
              <p class="quote-detail_desc" v-for="([key, value]) in Object.entries(selectData.common)" :key="key">
              <p v-show="value.length > 0">{{ key }}:</p>
              <p v-for="item in value" :key="item" class="quote-detail_child-desc">{{ item }}</p>
              </p>
            </div>
          </div>
          <div class="title" v-show="isShowing" @click="jump_2">
            Create Token
          </div>
          <div class="title" v-show="isShowing" @click="jump_3">Upload</div>
          <div class="title" v-show="isShowing" @click="jump_4">Manage Account</div>
        </el-aside>
        <el-container>
          <el-main>
            <div class="selections-container" v-show="true">
              <div class="header">
                <div class="label">Select Models</div>
                <el-select v-model="selectData.model" placeholder="Model Type" size="large" @change="onModelChange">
                  <el-option v-for="item in form.options" :key="item.Model" :label="item.Model" :value="item.Model" />
                </el-select>
              </div>
              <div class="header" v-show="selectData.model">
                <div class="label">Select Cranes</div>
                <el-select v-model="selectData.cranes" placeholder="Select Basic Crane" size="large" style="width: 20%"
                  @change="onCranesChange">
                  <el-option v-for="item in form.cranes" :key="item.Item_Number" :label="getLabel(item)"
                    :value="item.Item_Number">
                  </el-option>
                </el-select>
              </div>
              <div v-show="selectData.cranes">
                <div class="content" v-for="kind in ['specific', 'common']" :key="kind">
                  <div class="label">{{ kind === 'specific' ? 'Specific Options' : 'Common Options' }}</div>
                  <div class="select-item" v-for="([props, value]) in currentOptions(kind)" :key="props">
                    <div class="select-item_label">{{ props }}</div>
                    <el-select v-model="selectData[kind][props]" placeholder="Please Select" size="large" style="width: 70%"
                      multiple collapse-tags @change="(val) =>
                        onAllSelectChange(val, kind)">
                      <el-option v-for="item in value" :key="item.Item_Number" :label="getLabel(item, true)"
                        :value="item.Item_Number">
                        <el-input-number v-model="item.Count" :min="0" @click="onClickInput"
                          @change="(val) => onNumberChange(val, kind, props, item.Item_Number)" />
                        <span style="margin-left: 10px;">{{ getLabel(item) }}</span>
                        <span style="float: right;">{{ item.Price }}$</span>
                      </el-option>
                    </el-select>
                  </div>
                </div>
              </div>
              <el-button v-show="selectData.cranes" @click="jump" style="margin: 20px auto;">Generate PDF</el-button>
            </div>
          </el-main>
          <el-footer>Footer</el-footer>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
:deep(.el-table) thead tr th {
  background-color: rgb(245,247,250) !important;
}
.selections-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  >div {
    width: 100%;
    box-sizing: border-box;
  }
}
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    border: 1px solid #40525c;

    img {
      width: 220px;
    }
  }

  .el-aside {
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;

    .quote-detail {
      width: 100%;
      padding: 20px;
      box-sizing: border-box;
      border-bottom: 3px solid #40525c;

      .quote-detail_item:not(:last-child) {
        margin-bottom: 10px;
      }

      .quote-detail_title {
        font-weight: 800;
      }

      .quote-detail_desc {
        padding-left: 10px;
      }

      .quote-detail_child-desc {
        padding-left: 20px;
        font-size: 14px;
      }
    }

    .title {
      width: 100%;
      text-align: center;
      line-height: 50px;
      font-weight: bold;
      border-bottom: 3px solid #40525c;

      &:last-of-type {
        margin-bottom: 0;
      }

      &.active {
        // border-bottom-color: #0089d2;
        color: #0089d2;
      }

    }
  }

  .el-main {
    padding: 0;
    border-left: 3px solid #40525c;
    background-color: #ffffff;

    .header {
      border-bottom: 3px solid #40525c;
      padding: 20px;


      .label {
        font-weight: bold;
        margin-bottom: 10px;
        font-size: large;
      }
    }

    .content {
      padding: 20px;

      .select-item {
        margin-bottom: 10px;

        .select-item_label {
          padding-left: 10px;
          line-height: 24px;
        }
      }


      .label {
        font-weight: bold;
        margin-bottom: 10px;
        font-size: large;
      }

      .special_box {
        padding-left: 15px;

        &>span {
          font-size: 14px;
        }

        .special_title {
          padding: 10px 0 0;
          color: #9e565d;
          font-weight: bold;
          font-size: 15px;

          &.x {
            padding-top: 25px;
          }
        }

        .el-row {
          margin-top: 20px;
          padding-left: 10px;
        }
      }
    }
  }

  .el-footer {
    border-left: 3px solid #40525c;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
  }
}
</style>
