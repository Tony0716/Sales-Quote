<script setup>
import { reactive } from "vue";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import axios from "axios";

const router = useRouter();
const jump = () => {
  router.back();
};
const form = reactive({
  fname: "",
  lname: "",
  email: "",
  password: "",
  confirmP: "",
  token: "",
});

const signup = () => {
  if (form.fname == "") {
    ElMessage({
      message: "First Name cannot be empty",
      type: "warning",
    });
  } else if (form.lname == "") {
    ElMessage({
      message: "Last Name cannot be empty",
      type: "warning",
    });
  } else if (!checkEmail(form.email)) {
    ElMessage({
      message: "Please enter the correct email addresseckEmail",
      type: "warning",
    });
  } else if (form.password == "") {
    ElMessage({
      message: "The user password cannot be empty",
      type: "warning",
    });
  } else if (!comparisonP(form.password, form.confirmP)) {
    ElMessage({
      message: "Please ensure that the passwords entered twice are consistent",
      type: "warning",
    });
  } else if(form.taken == ""){
    ElMessage({
      message: "Taken cannot be empty",
      type: "warning",
    });
  } 
  else {
    // Send a login request to the backend
    axios
      .post("/signup", {
        firstName: form.fname,
        lastName: form.lname,
        email: form.email,
        password: form.password,
        token: form.token,
      })
      .then((response) => {
        // Handle the response from the backend here
        if (response.data.message === "Registration successful") {
          ElMessage({
            message: "Sign up succeed. Check your email for verification.",
            type: "success",
          });
          // Redirect to the home page upon successful login
          router.push("/login");
        } else if (response.data.message === "Email is already registered") {
          ElMessage({
            message: "Account Already Exist",
            type: "error",
          });
        } else if (response.data.message === "Invalid Token") {
          ElMessage({
            message: "Invalid Token",
            type: "error",
          });
        } else {
          ElMessage({
            message: "Sign Up failed",
            type: "error",
          });
        }
      })
      .catch((error) => {
        console.error(error);
        ElMessage({
          message: "An error occurred",
          type: "error",
        });
      });
  }
};
// 使用正则表达式来检查邮箱格式
const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
const checkEmail = (email) => {
  if (email == "") {
    return false;
  }
  return emailRegex.test(email);
};
const comparisonP = (a, b) => {
  if (a == "" || b == "") {
    return false;
  }
  if (a === b) {
    return true;
  } else {
    return false;
  }
};
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <img src="../assets/logo.png" alt="" />
      </el-header>
      <el-container>
        <el-main>
          <div class="title">Sign Up</div>
          <el-row :gutter="20">
            <el-col :span="6" :offset="9">
              <el-form :model="form" label-position="top" size="large">
                <el-form-item label="First Name">
                  <el-input v-model="form.fname" placeholder="First Name" />
                </el-form-item>
                <el-form-item label="Last Name">
                  <el-input v-model="form.lname" placeholder="Last Name" />
                </el-form-item>
                <el-form-item label="Email">
                  <el-input v-model="form.email" placeholder="name@email.com" />
                </el-form-item>
                <el-form-item label="Password">
                  <el-input
                    v-model="form.password"
                    placeholder="Enter Your Password"
                    type="password"
                    show-password
                  />
                </el-form-item>
                <el-form-item label="Confirm Password">
                  <el-input
                    v-model="form.confirmP"
                    placeholder="Enter Your Password"
                    type="password"
                    show-password
                  />
                </el-form-item>
                <el-form-item label="Token">
                  <el-input v-model="form.token" placeholder="Token" />
                </el-form-item>
                <el-form-item>
                  <el-button
                    size="large"
                    @click="signup"
                    style="
                      width: 100%;
                      background: #767171;
                      color: #fff;
                      height: 50px;
                      font-weight: bold;
                      font-size: 15px;
                    "
                  >
                    Sign Up
                  </el-button>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <div class="back" @click="jump">Back to sign in</div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped lang="scss">
.common-layout {
  .el-header {
    padding: 50px 0 47px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #e7e6e6;
    img {
      width: 220px;
    }
  }
  .el-aside {
    box-sizing: border-box;
    padding-top: 45px;
    display: flex;
    justify-content: center;
    height: calc(100vh - 99px);
    background-color: #ffffff;
    cursor: pointer;
  }
  .el-main {
    padding-top: 80px;
    height: calc(100vh - 99px);
    .title {
      font-size: 48px;
      padding-bottom: 50px;
      font-weight: bold;
      margin: 0 auto;
      text-align: center;
    }
    .back {
      padding-top: 90px;
      margin: 0 auto;
      text-align: center;
      cursor: pointer;
      font-size: large;
    }
  }
}
:deep(.el-form) {
  .el-form-item .el-form-item__label {
    font-size: large;
    color: black;
  }

  .el-input__inner {
    height: 50px !important;
  }
}
</style>
