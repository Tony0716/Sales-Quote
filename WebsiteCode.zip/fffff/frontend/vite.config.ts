import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  // server: {
  //   proxy: {
  //     "/*": {
  //       target: "http://3.129.205.133:8888/", // 你的 API 服务器地址
  //       changeOrigin: true,
  //     },
  //   },
  // },
});
