const express = require('express');
const { pool } = require('./db');

const router = express.Router();

router.get('/verify', async (req, res) => {
  const verificationToken = req.query.token;

  if (!verificationToken) {
    return res.status(400).json({ message: 'Invalid token' });
  }

  try {
    const connection = await pool.getConnection();
    const [results] = await connection.execute(
      'SELECT * FROM users WHERE verification_token = ?',
      [verificationToken]
    );

    if (results.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    const userEmail = results[0].email;

    await connection.execute('UPDATE users SET verified = 1 WHERE email = ?', [userEmail]);
    connection.release();

    res.status(200).json({ message: 'Email verification successful' });
  } catch (error) {
    console.error('Error during email verification:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;