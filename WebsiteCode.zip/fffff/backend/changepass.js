const express = require('express');
const { pool } = require('./db');

const router = express.Router();

router.post('/changep', async (req, res) => {
  const { email, old, newP} = req.body;

  try {
    const connection = await pool.getConnection();

    // Check if the email is already registered
    const [result] = await connection.execute(
      'SELECT * FROM users WHERE email = ? AND password = ?',
      [email, old]
    );

    if (result.length === 0) {
      connection.release();
      return res.json({ message: 'Incorrect' });
    }
    
    await connection.execute(
      'UPDATE users SET password=? WHERE email=?',
      [newP, email]
    );
    connection.release();

    res.status(200).json({ message: 'Password Changed' });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;