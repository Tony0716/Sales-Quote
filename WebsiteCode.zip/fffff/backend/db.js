const mysql = require('mysql2/promise')

//database connection
const db = {
    host: 'localhost',
    user: 'root',
    password: '483w',
    database: 'sales',
};
// Create a connection pool
const pool = mysql.createPool(db);

module.exports = {pool,};