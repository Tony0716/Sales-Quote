const express = require('express');
const jwt = require('jsonwebtoken');
const { pool } = require('./db');

const router = express.Router();
const secretKey = 'your_secret_key';

router.get('/token', async (req, res) => {
  const token = req.header('x-auth-token');
  
  if (!token) {
    console.error(error);
    return res.status(401).json({ message: 'No Token Provided' });
  }

  try {
    const decoded = jwt.verify(token, secretKey);

    if (decoded.role !== "admin"){
      return res.json({message: "Access Denied"});
    }

    try {
      const connection = await pool.getConnection();

      const [result] = await connection.execute(
        'SELECT token, createDate, role, status FROM tokens WHERE createBy = ?', [decoded.email]);
      connection.release();
     
      return res.json({ message: 'Permitted', rows: result });

    } catch (error) {
      console.error(error);
      return res.status(500).json({message: 'Internal server error'});
    }
  } catch (error) {
    console.error(error);
    return res.status(401).json({ message: 'Invalid token' });
  }
});

router.post('/token', async (req, res) => {
  const {token, role, jwt_token} = req.body;
  
  try {
    const decoded = jwt.verify(jwt_token, secretKey);
    const email = decoded.email;

    try {
      const connection = await pool.getConnection();

      const [tokens] = await connection.execute('SELECT * FROM tokens WHERE token = ?', [token]);
      if (tokens.length > 0 ){
        connection.release();
        return res.json({ message: 'Token alredy exist'});
      }
    
      await connection.query(
        'INSERT INTO tokens (token, createBy, role, status) values (?, ?, ?, ?)', [token, email, role, "not used"]);
      connection.release();
      return res.json({ message: 'Successful'});

    } catch (error) {
      console.error(error);
      return res.status(500).json({message: 'Internal server error'});
    }

  } catch (error) {
    console.error(error);
    return res.status(401).json({ message: 'Invalid jwt token' });
  }
});

router.delete('/token', async (req, res) =>{
  const token = req.query.token;
  try {
    await pool.query('DELETE FROM tokens WHERE token = ?', [token]);
    return res.json({message: 'Successful'});

  } catch (error) {
    console.error(error);
    req.status(500).json({message : 'Internal server error'});
  }
})


module.exports = router;