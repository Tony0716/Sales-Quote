const express = require('express');
const crypto = require('crypto');
const { pool } = require('./db');
const nodemailer = require('nodemailer');

const router = express.Router();

const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: 'bccalaman@gmail.com',
    pass: 'bijd odxh dwlh wxer',
  },
});

router.post('/signup', async (req, res) => {
  const { firstName, lastName, email, password, token } = req.body;
  
  try {
    const connection = await pool.getConnection();

  // Check token
    const [tokens] = await connection.execute(
      'SELECT * FROM tokens WHERE token = ?', [token]
    );

    if (tokens.length === 0 || tokens[0].status === 'used'){
      return res.json({message : 'Invalid Token'})
    }

    // Check if the email is already registered
    const [existingUser] = await connection.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (existingUser.length > 0) {
      connection.release();
      return res.json({ message: 'Email is already registered' });
    }

    // Generate a unique verification token
    const verificationToken = crypto.randomBytes(20).toString('hex');

    // Insert user data and verification token into the database
    await connection.execute(
      'INSERT INTO users (firstName, lastName, email, password, verification_token, role) VALUES (?, ?, ?, ?, ?, ?)',
      [firstName, lastName, email, password, verificationToken, tokens[0].role]
    );

    await connection.execute('UPDATE tokens SET status = ? WHERE token = ?', ["used", token]);

    connection.release();

    const verificationLink = `http://localhost:8888/verify?token=${verificationToken}`;

    const mailOptions = {
      from: 'bccalaman@gmail.com',
      to: email,
      subject: 'Email Verification',
      html: `<p>Click <a href="${verificationLink}">here</a> to verify your email.</p>`,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;