const express = require('express');
const { pool } = require('./db');

const router = express.Router();

function groupOptions(data) {
  const groups = {};
  data.forEach(option => {
    if (!groups[option.Category]) {
      groups[option.Category] = [];
    }
    groups[option.Category].push(option);
  });
  return groups;
}

router.get("/model", async (req, res) => {
  try {
      const connection = await pool.getConnection();

      const [result] = await connection.execute(
        'SELECT DISTINCT Model FROM models');
        if (result.length === 0){
            return res.json({message: 'No Data Available'});
        }
      connection.release();
        //console.log(result);
      return res.json({ message: 'Successful', models: result });

    } catch (error) {
      console.error(error);
      return res.status(500).json({message: 'Internal server error'});
    }
});

router.post("/getCraneByModel", async (req, res) => {
  const { model } = req.body;

  try {
      const connection = await pool.getConnection();

      const [result] = await connection.execute(
        'SELECT Item_Number, Description, Price FROM models WHERE Model = ? AND Type = "BASIC CRANE" ', [model]);
        if (result.length === 0){
            return res.json({message: 'No Data Available'});
        }
      connection.release();
        //console.log(result);
      return res.json({ message: 'Successful', cranes: result });

    } catch (error) {
      console.error(error);
      return res.status(500).json({message: 'Internal server error'});
    }
});

router.post("/getSpecificOptionsByCranes", async (req, res) => {
  const { model, crane } = req.body;

  try {
      const connection = await pool.getConnection();

      const [common] = await connection.execute(
        'SELECT Item_Number, Price, Description, Category, Type FROM models WHERE Model = ? AND Type = "COMMON OPTIONS" AND (Note = "" OR Note = ?)', [model, '%${crane}%']);

      const [specific] = await connection.execute(
      'SELECT Item_Number, Price, Description, Category, Type FROM models WHERE Model = ? AND Type = "SPECIFIC OPTIONS" AND (Note = "" OR Note = ?)', [model, '%${crane}%']);
        
        if (common.length === 0 && specific.length === 0){
            return res.json({message: 'No Data Available'});
        }
      connection.release();
      const groupedSpecific = groupOptions(specific);
      const groupedCommon = groupOptions(common);
      return res.json({ message: 'Successful', common: groupedCommon, specific: groupedSpecific });

    } catch (error) {
      console.error(error);
      return res.status(500).json({message: 'Internal server error'});
    }
});

module.exports = router;