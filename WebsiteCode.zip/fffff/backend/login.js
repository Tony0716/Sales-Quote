// login.js

const express = require('express');
const { pool } = require('./db');
const jwt = require('jsonwebtoken');

const router = express.Router();

// Handle user login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const connection = await pool.getConnection();

    // Check if the user exists with the given email
    const [user] = await connection.execute('SELECT * FROM users WHERE email = ?', [email]);

    if (user.length === 0) {
      connection.release();
      return res.json({ message: 'Login failed. Invalid credentials' });
    }

    // Check if the user's email is verified
    if (user[0].verified !== 1) {
      connection.release();
      return res.json({ message: 'Login failed. Email not verified' });
    }

    // Check if the provided password matches the stored password
    if (user[0].password !== password) {
      connection.release();
      return res.json({ message: 'Login failed. Invalid credentials' });
    }

    // User is authenticated
    
    const token = jwt.sign({email: user[0].email, firstName: user[0].firstName, lastName: user[0].lastName, role: user[0].role}, 'your_secret_key');
    connection.release();
    res.status(200).json({ message: 'Login successful' , jwt: token, role: user[0].role});
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;