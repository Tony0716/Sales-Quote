const express = require('express');
const path = require('path');
const registerRouter = require('./register.js');
const verifyRouter = require('./verify.js');
const loginRouter = require('./login.js');
const forgetpassRouter = require('./forgetpass.js');
const changepassRouter = require('./changepass.js');
const authenticationRouter = require('./authentication.js');
const uploadRouter = require('./upload.js');
const modelRouter = require('./model.js');
const manageAccount = require('./managerAccount')
const cors = require('cors');

const app = express(),
bodyParser = require('body-parser');
const port = 8888;

// Enable CORS
app.use(cors());
app.use(bodyParser.json());
app.use(express.json())
app.use(registerRouter);
app.use(changepassRouter);
app.use(verifyRouter);
app.use(forgetpassRouter);
app.use(loginRouter);
app.use(authenticationRouter);
app.use(uploadRouter);
app.use(modelRouter);
app.use(manageAccount)
app.use(express.static(path.join(__dirname, '../frontend/dist')));

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});