const express = require('express');
const { pool } = require('./db');
const csvtojson = require('csvtojson');
const multer = require('multer');
const router = express.Router();

// Multer setup for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + '.csv');
    }
});
const upload = multer({ storage: storage });

router.post('/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const filePath = req.file.path;
    const tableName = 'models'; // Replace with your actual table name

    try {
        // Clear the table
        await pool.query(`DELETE FROM ${tableName}`);

        // Convert CSV to JSON
        const jsonObj = await csvtojson().fromFile(filePath);

        // Insert each row
        for (const row of jsonObj) {
            const query = `INSERT INTO ${tableName} SET ?`;
            try {await pool.query(query, row);}
            catch{res.send('File is wrong')}
            
        }

        res.send('File uploaded and table data replaced!');
    } catch (err) {
        console.error('Error:', err);
        res.status(500).send('An error occurred');
    }
});

module.exports = router;
